import js from '@eslint/js';
import { includeIgnoreFile } from '@eslint/compat';
import mocha from 'eslint-plugin-mocha';
import prettier from 'eslint-config-prettier';
import globals from 'globals';
import path from 'path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default [
  js.configs.recommended,
  prettier,
  {
    plugins: { mocha },
    rules: {
      'mocha/no-async-suite': 'error',
    },
  },
  {
    languageOptions: {
      ecmaVersion: 2022,
      globals: {
        ...globals.browser,
        ...globals.mocha,
        ...globals.node,
      },
    },
  },
  includeIgnoreFile(path.resolve(__dirname, '.gitignore')),
];
