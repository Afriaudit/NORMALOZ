// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20Votes} from "../../token/ERC20/extensions/ERC20Votes.sol";
import {VotesExtended, Votes} from "../../governance/utils/VotesExtended.sol";
import {Time} from "../../utils/types/Time.sol";
import {ERC6372Utils} from "../../utils/ERC6372Utils.sol";

abstract contract ERC20VotesExtendedMock is ERC20Votes, VotesExtended {
    function _delegate(address account, address delegatee) internal virtual override(Votes, VotesExtended) {
        return super._delegate(account, delegatee);
    }

    function _transferVotingUnits(
        address from,
        address to,
        uint256 amount
    ) internal virtual override(Votes, VotesExtended) {
        return super._transferVotingUnits(from, to, amount);
    }
}

abstract contract ERC20VotesExtendedTimestampMock is ERC20VotesExtendedMock {
    function clock() public view override returns (uint48) {
        return Time.timestamp();
    }

    // solhint-disable-next-line func-name-mixedcase
    function CLOCK_MODE() public view virtual override returns (string memory) {
        return ERC6372Utils.timestampClockMode(clock);
    }
}
