// SPDX-License-Identifier: MIT

pragma solidity ^0.8.24;

import {ERC20Votes} from "../../token/ERC20/extensions/ERC20Votes.sol";
import {ERC721Votes} from "../../token/ERC721/extensions/ERC721Votes.sol";
import {Time} from "../../utils/types/Time.sol";
import {ERC6372Utils} from "../../utils/ERC6372Utils.sol";

abstract contract ERC20VotesTimestampMock is ERC20Votes {
    function clock() public view override returns (uint48) {
        return Time.timestamp();
    }

    // solhint-disable-next-line func-name-mixedcase
    function CLOCK_MODE() public view virtual override returns (string memory) {
        return ERC6372Utils.timestampClockMode(clock);
    }
}

abstract contract ERC721VotesTimestampMock is ERC721Votes {
    function clock() public view override returns (uint48) {
        return Time.timestamp();
    }

    // solhint-disable-next-line func-name-mixedcase
    function CLOCK_MODE() public view virtual override returns (string memory) {
        return ERC6372Utils.timestampClockMode(clock);
    }
}
